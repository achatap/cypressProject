/// <reference types="cypress" /> 

it('First test using cypress', ()=>{

    cy.visit("https://google.com")

})